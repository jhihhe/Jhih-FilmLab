# FilmLab presentation changes

Maintainer: @Jhih he. Upstream authors and license notices remain unchanged.

The shared fp_usb_shell/build_autorun.py now accepts optional --progress-label
(default fpSup), --progress-width (default8), and --text-y (default16). Default loader/entry/cache/restore
behavior is unchanged. FilmLab uses its own label and y112. These are generator
options, not hand edits to generated artifacts or a separate load chain.

The resident FilmLab owns its rectangle renderer and curved apostrophe glyph.
It invokes the firmware surface, rectangle, font and present APIs and does not
patch those functions. No whole-layer clear occurs during resident HUD redraw.
The generated FilmLab package selects FilmLab.BIN through the upstream generator’s --bin-name option; the upstream default remains fpSup.BIN.
