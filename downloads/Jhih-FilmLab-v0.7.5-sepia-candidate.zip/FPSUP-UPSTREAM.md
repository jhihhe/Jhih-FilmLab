Source: https://github.com/ijigen/fpSup
Pinned commit: 199ced0a87e9a235f4651315c3044ee8163ebd2f
Upstream author: ijigen; original notices retained.
Locally copied build dependency: fp_usb_shell/, SUP_BUILD_RULES.en.md.
No standalone LICENSE file was present in this checkout's root.
First-party integration maintainer: @Jhih he.
